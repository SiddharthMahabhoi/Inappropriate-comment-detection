"""Modern Flatlogic Sing App-inspired Enterprise Trust & Safety CSS.

Optimized for:
- Full widescreen utilization (100% viewport, optimal 3-panel ratio)
- High contrast typography for effortless reading (14px-15px body, dark slate text #0F172A)
- Distinct, readable chat bubbles with clear speaker hierarchy
- High-visibility status and violation pills
- Royal blue executive risk profile card (#0284C7 to #2563EB)
- Vibrant orange action button (#FF5722)
- Interactive System Help & Documentation modal/drawer
"""

DASHBOARD_CUSTOM_CSS = """
<style>
/* Outer Page Canvas - Soft Pastel Sky Blue with Subtle Dotted Pattern */
.stApp {
    background-color: #EBF2FA !important;
    background-image: radial-gradient(#CFE0F5 1.2px, transparent 1.2px) !important;
    background-size: 24px 24px !important;
    color: #0F172A !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
}

/* Hide Streamlit Boilerplate */
header[data-testid="stHeader"] {
    display: none !important;
}
footer {
    display: none !important;
}
#MainMenu {
    display: none !important;
}

/* Maximize Screen Utilization */
.block-container {
    padding-top: 0.8rem !important;
    padding-bottom: 1.5rem !important;
    padding-left: 1.5rem !important;
    padding-right: 1.5rem !important;
    max-width: 100% !important;
}

/* Top Navigation Bar / Header Toolbar */
.enterprise-top-bar {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 16px;
    padding: 12px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
    margin-bottom: 14px;
}

.top-bar-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.brand-title {
    font-size: 1.35rem;
    font-weight: 800;
    color: #0F172A;
    letter-spacing: -0.02em;
    display: flex;
    align-items: center;
    gap: 8px;
}

.brand-badge {
    font-size: 0.78rem;
    font-weight: 700;
    color: #1D4ED8;
    background: #EFF6FF;
    border: 1px solid #BFDBFE;
    border-radius: 6px;
    padding: 3px 9px;
}

.status-chip {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.82rem;
    font-weight: 600;
    color: #334155;
    background: #F8FAFC;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    padding: 4px 12px;
}

.status-dot-green {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #10B981;
}

.top-bar-right {
    display: flex;
    align-items: center;
    gap: 12px;
}

/* Main 3-Panel Wrapper */
.enterprise-workspace-wrapper {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 18px;
    box-shadow: 0 10px 35px rgba(0, 0, 0, 0.04);
    padding: 20px 22px;
    margin-bottom: 18px;
}

/* Panel A: Left Monitored Queue */
.panel-section-title {
    font-size: 0.85rem;
    font-weight: 800;
    color: #475569;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.thread-item-card {
    padding: 12px 14px;
    border-radius: 12px;
    background-color: #F8FAFC;
    border: 1px solid #E2E8F0;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all 0.15s ease;
}

.thread-item-card:hover {
    background-color: #F1F5F9;
    border-color: #CBD5E1;
}

.thread-item-active {
    background-color: #0284C7 !important;
    border-color: #0284C7 !important;
    color: #FFFFFF !important;
    box-shadow: 0 6px 16px rgba(2, 132, 199, 0.28) !important;
}

.thread-item-active .thread-meta-sub {
    color: #E0F2FE !important;
}

.thread-title-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.92rem;
    font-weight: 700;
}

.thread-meta-sub {
    font-size: 0.80rem;
    color: #64748B;
    margin-top: 4px;
    line-height: 1.35;
}

/* Panel B: Center Chat Stream */
.center-chat-stream {
    border-left: 1px solid #F1F5F9;
    border-right: 1px solid #F1F5F9;
    padding: 0 20px;
    height: 100%;
}

.stream-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 14px;
    border-bottom: 1px solid #F1F5F9;
    margin-bottom: 16px;
}

.stream-title {
    font-size: 1.25rem;
    font-weight: 800;
    color: #0F172A;
}

.stream-subtitle {
    font-size: 0.82rem;
    color: #0284C7;
    font-weight: 600;
    margin-top: 2px;
}

/* Message Bubbles - High Contrast & Legible */
.msg-row-incoming {
    display: flex;
    gap: 12px;
    align-items: flex-start;
    margin-bottom: 16px;
}

.msg-row-outgoing {
    display: flex;
    gap: 12px;
    align-items: flex-start;
    justify-content: flex-end;
    margin-bottom: 16px;
}

.msg-avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 0.82rem;
    flex-shrink: 0;
}

.avatar-dark {
    background-color: #1E293B;
    color: #FFFFFF;
}

.avatar-blue {
    background: linear-gradient(135deg, #0284C7 0%, #2563EB 100%);
    color: #FFFFFF;
}

.avatar-red {
    background-color: #DC2626;
    color: #FFFFFF;
}

.msg-bubble-left {
    background-color: #FFFFFF;
    border: 1px solid #CBD5E1;
    border-radius: 4px 16px 16px 16px;
    padding: 14px 18px;
    max-width: 86%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
}

.msg-bubble-flagged {
    background-color: #FFF5F5;
    border: 2px solid #EF4444 !important;
    border-radius: 4px 16px 16px 16px;
    padding: 14px 18px;
    max-width: 86%;
    box-shadow: 0 6px 18px rgba(239, 68, 68, 0.12);
}

.msg-bubble-right {
    background: linear-gradient(135deg, #0284C7 0%, #2563EB 100%);
    color: #FFFFFF;
    border-radius: 16px 4px 16px 16px;
    padding: 14px 18px;
    max-width: 86%;
    box-shadow: 0 4px 14px rgba(2, 132, 199, 0.22);
}

.msg-header-bar {
    font-size: 0.80rem;
    font-weight: 700;
    color: #475569;
    margin-bottom: 6px;
    display: flex;
    justify-content: space-between;
    gap: 10px;
}

.msg-text-content {
    font-size: 0.95rem;
    line-height: 1.55;
    color: #0F172A;
    font-weight: 500;
}

.msg-bubble-right .msg-text-content {
    color: #FFFFFF !important;
}

.msg-time-tag {
    font-size: 0.72rem;
    color: #64748B;
}

/* Violation Pills - High Contrast */
.violation-tag {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 800;
    margin-right: 5px;
    margin-top: 6px;
}

.tag-red {
    background-color: #FEE2E2;
    color: #991B1B;
    border: 1px solid #FCA5A5;
}

.tag-amber {
    background-color: #FEF3C7;
    color: #92400E;
    border: 1px solid #FDE68A;
}

.tag-green {
    background-color: #DCFCE7;
    color: #166534;
    border: 1px solid #86EFAC;
}

/* Bottom Simulator Bar */
.stream-input-bar {
    padding-top: 14px;
    border-top: 1px solid #F1F5F9;
    margin-top: 16px;
}

/* Orange Send Button */
div.stButton > button[kind="primary"] {
    background: linear-gradient(135deg, #FF5722 0%, #F4511E 100%) !important;
    border: none !important;
    color: #FFFFFF !important;
    font-weight: 700 !important;
    font-size: 0.90rem !important;
    border-radius: 8px !important;
    padding: 0.55rem 1.4rem !important;
    box-shadow: 0 4px 12px rgba(255, 87, 34, 0.35) !important;
    transition: all 0.15s ease !important;
}

div.stButton > button[kind="primary"]:hover {
    background-color: #E64A19 !important;
    box-shadow: 0 6px 16px rgba(255, 87, 34, 0.45) !important;
}

/* Panel C: Right Executive Risk Card */
.executive-risk-card {
    background: linear-gradient(135deg, #0284C7 0%, #2563EB 100%);
    border-radius: 18px;
    padding: 22px;
    color: #FFFFFF;
    margin-bottom: 16px;
    box-shadow: 0 8px 24px rgba(2, 132, 199, 0.28);
}

.risk-card-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.risk-headline {
    font-size: 1.35rem;
    font-weight: 800;
    color: #FFFFFF;
    line-height: 1.2;
}

.risk-subtext {
    font-size: 0.88rem;
    color: #E0F2FE;
    margin-top: 4px;
    font-weight: 600;
}

.risk-badge-icon {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    border: 3px solid rgba(255, 255, 255, 0.85);
    background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
    font-weight: 800;
    color: #FFFFFF;
}

.risk-badge-icon-green {
    background: linear-gradient(135deg, #10B981 0%, #059669 100%) !important;
}

.risk-metrics-row {
    font-size: 0.85rem;
    color: #E0F2FE;
    margin-top: 14px;
    padding-top: 10px;
    border-top: 1px solid rgba(255, 255, 255, 0.25);
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 600;
}

.risk-action-bar {
    display: flex;
    gap: 10px;
    margin-top: 14px;
}

.risk-action-btn {
    padding: 6px 12px;
    border-radius: 8px;
    background-color: rgba(255, 255, 255, 0.2);
    font-size: 0.78rem;
    font-weight: 700;
    color: #FFFFFF;
    cursor: pointer;
    border: 1px solid rgba(255, 255, 255, 0.3);
    transition: all 0.15s ease;
}

.risk-action-btn:hover {
    background-color: #FFFFFF;
    color: #0284C7;
}

/* Accordion Drawer Cards */
.info-drawer-card {
    background-color: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 14px 16px;
    margin-bottom: 12px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

.info-drawer-title {
    font-size: 0.90rem;
    font-weight: 800;
    color: #0F172A;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.info-drawer-body {
    font-size: 0.85rem;
    color: #334155;
    line-height: 1.6;
}

/* Token Occlusion Saliency Tags */
.token-trigger-tag {
    background-color: #FEE2E2;
    color: #991B1B;
    font-weight: 800;
    padding: 2px 7px;
    border-radius: 6px;
    border: 1px solid #FCA5A5;
    display: inline-block;
    margin: 2px 2px;
}

.token-mitigating-tag {
    background-color: #DCFCE7;
    color: #166534;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 6px;
    border: 1px solid #86EFAC;
    display: inline-block;
    margin: 2px 2px;
}

/* Help Box Modal / Drawer */
.help-guide-banner {
    background: #EFF6FF;
    border: 1px solid #BFDBFE;
    border-radius: 14px;
    padding: 18px 22px;
    margin-bottom: 18px;
}

.help-guide-title {
    font-size: 1.15rem;
    font-weight: 800;
    color: #1E40AF;
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.help-guide-step {
    background: #FFFFFF;
    border: 1px solid #DBEAFE;
    border-radius: 10px;
    padding: 12px 14px;
    font-size: 0.85rem;
    color: #1E293B;
    line-height: 1.5;
}

/* Footer Row */
.enterprise-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 20px;
    font-size: 0.80rem;
    color: #64748B;
    border-top: 1px solid #E2E8F0;
    margin-top: 10px;
}
</style>
"""
