"""Unit tests for Stage 2 Preprocessing Module.

Verifies:
- Missing/null/whitespace-only input handling
- URL normalization (http, https, www, markdown links)
- User mention normalization (/u/user, u/user, @user)
- Preservation of punctuation (question marks, exclamation marks, quotes, ellipsis)
- Preservation of negation ("not", "n't", "never", "cannot")
- Preservation of capitalization (shouting/hostility indicators)
- Preservation of Unicode characters, accents, and emojis
- Determinism and separation of original_text vs cleaned_text
"""

import pytest
import pandas as pd
from src.preprocessing import ConversationPreprocessor


@pytest.fixture
def preprocessor() -> ConversationPreprocessor:
    return ConversationPreprocessor(
        url_placeholder="[URL]",
        user_placeholder="[USER]",
        subreddit_placeholder="[SUBREDDIT]",
        normalize_unicode=True,
        preserve_casing=True,
    )


def test_missing_and_empty_text(preprocessor: ConversationPreprocessor):
    """Verify that null, empty, and whitespace strings are handled safely without exceptions."""
    assert preprocessor.clean_text(None) == ""
    assert preprocessor.clean_text("") == ""
    assert preprocessor.clean_text("   \n\t  ") == ""
    assert preprocessor.clean_text(12345) == "12345"


def test_url_replacement(preprocessor: ConversationPreprocessor):
    """Verify standard and markdown URLs are replaced with [URL]."""
    text_http = "Check this source: http://example.com/data for proof."
    assert preprocessor.clean_text(text_http) == "Check this source: [URL] for proof."

    text_https = "See https://en.wikipedia.org/wiki/ChangeMyView for info."
    assert preprocessor.clean_text(text_https) == "See [URL] for info."

    text_www = "Visit www.example.org/path?arg=1 today."
    assert preprocessor.clean_text(text_www) == "Visit [URL] today."

    text_md = "Refer to [official report](https://gov.org/report.pdf) now."
    assert preprocessor.clean_text(text_md) == "Refer to official report [URL] now."


def test_user_mentions_normalization(preprocessor: ConversationPreprocessor):
    """Verify Reddit user mentions (/u/name, u/name, @name) are replaced with [USER]."""
    text_reddit_slash = "I strongly disagree with /u/john_doe on this point."
    assert preprocessor.clean_text(text_reddit_slash) == "I strongly disagree with [USER] on this point."

    text_reddit_noslash = "As u/sarah-smith explained earlier..."
    assert preprocessor.clean_text(text_reddit_noslash) == "As [USER] explained earlier..."

    text_at = "Paging @moderator for review."
    assert preprocessor.clean_text(text_at) == "Paging [USER] for review."


def test_punctuation_preservation(preprocessor: ConversationPreprocessor):
    """Verify that meaningful punctuation (quotes, repeated marks, ellipsis) is preserved."""
    text = 'He said "You are completely wrong!" and asked "Are you serious??? Why would you do that?!"'
    cleaned = preprocessor.clean_text(text)
    assert '"You are completely wrong!"' in cleaned
    assert '???' in cleaned
    assert '?!' in cleaned


def test_negation_preservation(preprocessor: ConversationPreprocessor):
    """Verify that negation words critical for toxicity and stance are preserved."""
    text = "I do not agree, I cannot accept this, and it isn't true at all. Never say that."
    cleaned = preprocessor.clean_text(text)
    assert "not" in cleaned
    assert "cannot" in cleaned
    assert "isn't" in cleaned
    assert "Never" in cleaned


def test_capitalization_preservation(preprocessor: ConversationPreprocessor):
    """Verify capitalization is preserved because ALL CAPS conveys shouting/aggression."""
    text = "WHY ARE YOU SHOUTING AT ME? Stop it."
    cleaned = preprocessor.clean_text(text)
    assert "WHY ARE YOU SHOUTING AT ME?" in cleaned
    assert "Stop it." in cleaned


def test_unicode_and_emoji_preservation(preprocessor: ConversationPreprocessor):
    """Verify emojis and Unicode accented characters are preserved."""
    text = "That is naïve of you! 😠 Very disappointing 👎 But great effort 👏"
    cleaned = preprocessor.clean_text(text)
    assert "naïve" in cleaned
    assert "😠" in cleaned
    assert "👎" in cleaned
    assert "👏" in cleaned


def test_sarcasm_and_quotes_preservation(preprocessor: ConversationPreprocessor):
    """Verify sarcasm indicator /s and single/double quotes remain intact."""
    text = "Oh sure, that makes total sense. /s Just 'brilliant' logic."
    cleaned = preprocessor.clean_text(text)
    assert "/s" in cleaned
    assert "'brilliant'" in cleaned


def test_whitespace_normalization(preprocessor: ConversationPreprocessor):
    """Verify excessive spaces and multiple blank lines are normalized cleanly."""
    text = "First line.    Multiple   spaces.\n\n\n\nSecond paragraph.\r\nThird line."
    cleaned = preprocessor.clean_text(text)
    assert "First line. Multiple spaces." in cleaned
    assert "\n\n" in cleaned
    assert "\n\n\n" not in cleaned


def test_dataframe_preprocessing(preprocessor: ConversationPreprocessor):
    """Verify DataFrame preprocessing preserves both original and cleaned columns alongside metadata."""
    df = pd.DataFrame([
        {"id": "c1", "conversation_id": "t1", "text": "Visit https://test.com /u/bob!", "speaker": "alice"},
        {"id": "c2", "conversation_id": "t1", "text": None, "speaker": "bob"},
    ])

    processed_df = preprocessor.preprocess_dataframe(df)

    assert "cleaned_text" in processed_df.columns
    assert "original_text" in processed_df.columns
    assert processed_df.loc[0, "cleaned_text"] == "Visit [URL] [USER]!"
    assert processed_df.loc[1, "cleaned_text"] == ""
    assert processed_df.loc[0, "speaker"] == "alice"
    assert processed_df.loc[0, "conversation_id"] == "t1"


def test_determinism(preprocessor: ConversationPreprocessor):
    """Verify identical inputs yield identical outputs across repeated calls."""
    sample = "Hey @user check http://link.com! 😠 Are you serious??? Not at all."
    out1 = preprocessor.clean_text(sample)
    out2 = preprocessor.clean_text(sample)
    assert out1 == out2
