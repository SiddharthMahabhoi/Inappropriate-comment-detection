"""Comprehensive Unit and Integration Tests for Phase 2 and Phase 3 Components.

Tests:
1. Stage 4: Multi-label classification (TF-IDF Baseline, RoBERTa head, metrics, threshold tuning)
2. Stage 5: Context integration (Causal history aggregation, strict anti-leakage)
3. Stage 6: Derailment forecasting (Prefix generation without future leakage, GRU trajectory)
4. Stage 7: Severity grading (Provisional risk calculation, band assignment, driver identification)
5. Stage 8: Explainability (Token occlusion attribution, faithfulness drop)
"""

import json
import numpy as np
import pytest
import torch

from src.classifier import (
    EXTENDED_LABELS,
    TARGET_LABELS,
    RoBERTaMultiLabelClassifier,
    TfidfMultiLabelBaseline,
    compute_multilabel_metrics,
)
from src.context_encoder import CommentOnlyClassifier, ContextAwareClassifier, ConversationHistoryAggregator
from src.explainability import CommentExplainer
from src.forecasting import ConversationPrefixGenerator, CraftInspiredGRU, DerailmentForecastingEngine
from src.severity import SeverityGradingEngine


def test_tfidf_baseline_train_predict():
    """Verify TF-IDF baseline fits, tunes thresholds, and outputs valid binary indicators."""
    train_texts = [
        "This is a wonderful and polite comment.",
        "You are a stupid idiot and I hate you.",
        "Threatening to kill someone is illegal.",
        "Clean discussion on economics and philosophy.",
    ]
    # Labels: ['toxic', 'insult', 'threat', 'obscene', 'identity_hate']
    y_train = np.array([
        [0, 0, 0, 0, 0],
        [1, 1, 0, 1, 0],
        [1, 0, 1, 0, 0],
        [0, 0, 0, 0, 0],
    ])

    val_texts = [
        "Great point, thanks for sharing.",
        "You are so dumb.",
    ]
    y_val = np.array([
        [0, 0, 0, 0, 0],
        [1, 1, 0, 0, 0],
    ])

    baseline = TfidfMultiLabelBaseline(labels=TARGET_LABELS, max_features=100)
    baseline.fit(train_texts, y_train, val_texts, y_val)

    assert baseline.is_trained
    probs = baseline.predict_proba(["You are an idiot!"])
    assert probs.shape == (1, 5)
    assert (probs >= 0.0).all() and (probs <= 1.0).all()

    preds = baseline.predict(["You are an idiot!"])
    assert preds.shape == (1, 5)
    assert set(np.unique(preds)).issubset({0, 1})


def test_roberta_neural_head():
    """Verify RoBERTa neural multi-label head initializes, trains, and predicts sigmoid probabilities."""
    X_train = np.random.randn(8, 768).astype(np.float32)
    y_train = np.array([
        [0, 0, 0, 0, 0],
        [1, 1, 0, 0, 0],
        [0, 0, 1, 0, 0],
        [1, 0, 0, 1, 0],
        [0, 0, 0, 0, 1],
        [1, 1, 0, 1, 0],
        [0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0],
    ])

    X_val = np.random.randn(4, 768).astype(np.float32)
    y_val = np.array([
        [0, 0, 0, 0, 0],
        [1, 1, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [1, 0, 0, 1, 0],
    ])

    clf = RoBERTaMultiLabelClassifier(labels=TARGET_LABELS, epochs=2, batch_size=4)
    res = clf.fit(X_train, y_train, X_val, y_val)

    assert clf.is_trained
    assert "best_val_loss" in res

    probs = clf.predict_proba(X_val)
    assert probs.shape == (4, 5)
    assert np.isfinite(probs).all()


def test_multilabel_metrics():
    """Verify multi-label metric computation."""
    y_true = np.array([[1, 0, 0], [0, 1, 0], [1, 1, 0]])
    y_pred = np.array([[1, 0, 0], [0, 1, 1], [1, 1, 0]])
    y_prob = np.array([[0.9, 0.1, 0.1], [0.2, 0.8, 0.6], [0.85, 0.75, 0.2]])

    metrics = compute_multilabel_metrics(y_true, y_pred, y_prob, labels=["a", "b", "c"])
    assert "macro_f1" in metrics
    assert "micro_f1" in metrics
    assert "hamming_loss" in metrics
    assert len(metrics["per_label"]) == 3


def test_context_aggregation_causality():
    """Verify context aggregator strictly observes chronological order without future leakage."""
    aggregator = ConversationHistoryAggregator(max_history_turns=3)

    thread_comments = [
        {"id": "u1", "conversation_id": "c1", "timestamp": 100, "text": "First comment"},
        {"id": "u2", "conversation_id": "c1", "timestamp": 200, "text": "Second comment"},
        {"id": "u3", "conversation_id": "c1", "timestamp": 300, "text": "Third comment"},
    ]
    embs = {
        "u1": np.ones(768, dtype=np.float32) * 1.0,
        "u2": np.ones(768, dtype=np.float32) * 2.0,
        "u3": np.ones(768, dtype=np.float32) * 3.0,
    }

    features = aggregator.build_context_features(thread_comments, embs)
    assert len(features) == 3

    # Turn 1 (root post): context must be zero vector
    assert np.allclose(features[0]["context_emb"], np.zeros(768))
    assert features[0]["history_ids"] == []

    # Turn 2: history contains only u1
    assert features[1]["history_ids"] == ["u1"]
    assert np.allclose(features[1]["context_emb"], embs["u1"])

    # Turn 3: history contains u1 and u2 (u3 is NEVER in its own history)
    assert features[2]["history_ids"] == ["u1", "u2"]
    assert "u3" not in features[2]["history_ids"]


def test_forecasting_prefix_no_leakage():
    """Verify forecasting prefix generator stops before any personal attack comment."""
    gen = ConversationPrefixGenerator(min_prefix=1, max_prefix=5)

    thread_utts = [
        {"id": "u1", "conversation_id": "t1", "text": "Hello", "meta_comment_has_personal_attack": False},
        {"id": "u2", "conversation_id": "t1", "text": "I disagree", "meta_comment_has_personal_attack": False},
        {"id": "u3", "conversation_id": "t1", "text": "You are stupid!", "meta_comment_has_personal_attack": True},  # Attack!
        {"id": "u4", "conversation_id": "t1", "text": "Stop insulting", "meta_comment_has_personal_attack": False},
    ]

    prefixes = gen.generate_prefixes_from_thread(thread_utts, conversation_will_derail=True)

    # Must only generate prefixes for u1 and u1+u2; NEVER include u3 or u4!
    assert len(prefixes) == 2
    assert prefixes[0].utterance_ids == ["u1"]
    assert prefixes[1].utterance_ids == ["u1", "u2"]
    for p in prefixes:
        assert "u3" not in p.utterance_ids
        assert "u4" not in p.utterance_ids
        assert p.will_derail == 1


def test_severity_grading_bands():
    """Verify severity engine maps probabilities to correct bands and flags provisionality."""
    engine = SeverityGradingEngine()

    # Civil sample
    low = engine.assess_severity({"toxic": 0.05, "insult": 0.02, "threat": 0.01})
    assert low.severity_band == "Low"
    assert low.is_provisional is True

    # Moderate insult
    med = engine.assess_severity({"toxic": 0.55, "insult": 0.50, "threat": 0.01})
    assert med.severity_band == "Medium"

    # Threat sample
    crit = engine.assess_severity({"toxic": 0.85, "insult": 0.70, "threat": 0.40})
    assert crit.severity_band == "Critical"
    assert "threat" in crit.explanation.lower()


def test_token_occlusion_explainer():
    """Verify leave-one-out explainer computes attribution deltas and faithfulness drop."""
    # Mock classifier: outputs high probability if word "bad" is present
    def mock_predict(texts):
        probs = []
        for t in texts:
            p = 0.90 if "bad" in t.lower() else 0.10
            probs.append([p])
        return np.array(probs)

    explainer = CommentExplainer(predict_fn=mock_predict)
    res = explainer.explain_text_occlusion("This is very bad news", label_index=0, label_name="toxic")

    assert res.target_label == "toxic"
    assert res.base_probability == 0.90
    assert "bad" in res.top_hostile_tokens
    assert res.faithfulness_drop > 0.0  # Removing "bad" drops probability from 0.90 to 0.10!

