"""End-to-End System Integration Test for Phase 2 & Phase 3.

Verifies:
1. Loading saved model artifacts from outputs/models
2. End-to-end inference pipeline: Raw text -> Preprocessing -> Multi-label prediction -> Severity grading -> Explainability
3. Valid probability outputs and schema compliance
"""

import json
from pathlib import Path
import numpy as np
import pytest

from src.classifier import TfidfMultiLabelBaseline
from src.embeddings import CommentEmbeddingGenerator
from src.explainability import CommentExplainer
from src.preprocessing import ConversationPreprocessor
from src.severity import SeverityGradingEngine

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def test_end_to_end_prediction_flow():
    """Verify that saved artifacts perform end-to-end inference without error."""
    baseline_dir = PROJECT_ROOT / "outputs" / "models" / "baseline_tfidf"
    assert baseline_dir.exists(), "Trained baseline directory missing!"

    # 1. Load components
    preprocessor = ConversationPreprocessor()
    baseline = TfidfMultiLabelBaseline.load(baseline_dir)
    severity_engine = SeverityGradingEngine()

    raw_text = "You are a complete idiot, get out of here right now!"

    # 2. Preprocessing
    cleaned_text = preprocessor.clean_text(raw_text)
    assert len(cleaned_text) > 0

    # 3. Multi-label Prediction
    probs = baseline.predict_proba([cleaned_text])[0]
    preds = baseline.predict([cleaned_text])[0]

    assert len(probs) == len(baseline.labels)
    assert (probs >= 0.0).all() and (probs <= 1.0).all()

    prob_dict = {lbl: float(probs[i]) for i, lbl in enumerate(baseline.labels)}

    # 4. Severity Assessment
    assessment = severity_engine.assess_severity(prob_dict, derailment_probability=0.45)
    assert assessment.severity_band in ["Low", "Medium", "High", "Critical"]
    assert assessment.is_provisional is True
    assert 0.0 <= assessment.numerical_risk_score <= 1.0

    # 5. Explainability
    explainer = CommentExplainer(predict_fn=baseline.predict_proba)
    exp_res = explainer.explain_text_occlusion(cleaned_text, label_index=0, label_name="toxic", top_k=5)

    assert exp_res.target_label == "toxic"
    assert len(exp_res.token_attributions) > 0
    assert any(a.token.lower() == "idiot" and a.attribution_score > 0 for a in exp_res.token_attributions)


def test_dashboard_backend_integration():
    """Verify that dashboard backend orchestration operates correctly across threads."""
    from src.dashboard_backend import (
        get_default_benchmark_threads,
        load_all_resources,
        load_or_initialize_reviews,
        run_conversation_inference,
        update_review_record,
    )

    resources = load_all_resources()
    assert resources["preprocessor"] is not None
    assert resources["severity_engine"] is not None

    benchmarks = get_default_benchmark_threads()
    assert "Wikipedia Deliberation Escalating to Attack (Thread #748)" in benchmarks
    thread = benchmarks["Wikipedia Deliberation Escalating to Attack (Thread #748)"]

    res = run_conversation_inference(thread, resources, model_choice="baseline")
    assert res["total_turns"] == 6
    assert res["highest_severity_band"] in ["Low", "Medium", "High", "Critical"]
    assert "turns" in res
    assert len(res["turns"]) == 6
    assert res["turns"][5]["is_flagged"] is True

    reviews = load_or_initialize_reviews()
    assert len(reviews) > 0
    first_id = reviews[0]["review_id"]
    updated = update_review_record(first_id, new_status="Reviewed", moderator_notes="Test note")
    assert updated is True

