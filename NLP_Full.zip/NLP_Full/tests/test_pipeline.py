"""Integration and Component Tests for Phase 1 NLP Pipeline.

Verifies:
- Data loader functionality and conversation tree reconstruction
- Preprocessing integration
- Embedding generation, dimensionality, finite values, and 1-to-1 mapping
- End-to-end pipeline execution on a test subset
"""

import json
import os
import shutil
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from src.data_loader import CommentRecord, ConversationDataLoader, ConversationThread
from src.embeddings import CommentEmbeddingGenerator
from src.preprocessing import ConversationPreprocessor


@pytest.fixture
def sample_comments():
    return [
        {
            "comment_id": "c1",
            "conversation_id": "thread_1",
            "speaker": "AuthorA",
            "reply_to": None,
            "timestamp": 1000.0,
            "original_text": "Vaccines have proven track records. Look at https://who.int/vaccines for data.",
            "is_root": True,
            "depth": 0,
            "split": "train",
        },
        {
            "comment_id": "c2",
            "conversation_id": "thread_1",
            "speaker": "AuthorB",
            "reply_to": "c1",
            "timestamp": 1050.0,
            "original_text": "I disagree with /u/AuthorA! You are ignoring the side effects ???",
            "is_root": False,
            "depth": 1,
            "split": "train",
        },
        {
            "comment_id": "c3",
            "conversation_id": "thread_1",
            "speaker": "AuthorA",
            "reply_to": "c2",
            "timestamp": 1100.0,
            "original_text": "That is NOT true. Look at the numbers closely.",
            "is_root": False,
            "depth": 2,
            "split": "train",
        },
    ]


def test_comment_record_data_structures():
    """Verify CommentRecord and ConversationThread data structures."""
    rec = CommentRecord(
        comment_id="c1",
        conversation_id="conv_1",
        speaker="User1",
        reply_to=None,
        timestamp=100.0,
        original_text="Hello world",
        is_root=True,
        depth=0,
    )
    d = rec.to_dict()
    assert d["comment_id"] == "c1"
    assert d["is_root"] is True
    assert d["depth"] == 0

    thread = ConversationThread(
        conversation_id="conv_1",
        split="train",
        has_removed_comment=False,
        comments=[rec],
        root_id="c1",
    )
    assert thread.comment_count == 1
    tree_text = thread.format_tree()
    assert "conv_1" in tree_text
    assert "[OP]" in tree_text


def test_preprocessing_integration(sample_comments):
    """Verify that preprocessing integrates cleanly with comment records."""
    preprocessor = ConversationPreprocessor()
    cleaned = [preprocessor.preprocess_record(c) for c in sample_comments]

    assert len(cleaned) == 3
    # Check c1 URL replaced
    assert "[URL]" in cleaned[0]["cleaned_text"]
    assert "https://who.int" not in cleaned[0]["cleaned_text"]

    # Check c2 mention replaced and punctuation preserved
    assert "[USER]" in cleaned[1]["cleaned_text"]
    assert "???" in cleaned[1]["cleaned_text"]

    # Check c3 negation and capitalization preserved
    assert "NOT" in cleaned[2]["cleaned_text"]

    # Check original_text is untouched
    assert "https://who.int" in cleaned[0]["original_text"]


def test_embedding_generation_synthetic(sample_comments):
    """Verify embedding generator outputs finite floats with correct shape and mapping."""
    preprocessor = ConversationPreprocessor()
    cleaned_records = [preprocessor.preprocess_record(c) for c in sample_comments]

    with tempfile.TemporaryDirectory() as tmp_dir:
        generator = CommentEmbeddingGenerator(
            model_name="sentence-transformers/all-distilroberta-v1",
            device="cpu",
            batch_size=2,
        )

        embeddings, meta_df, manifest = generator.generate_embeddings(
            records=cleaned_records,
            output_dir=tmp_dir,
            force_recompute=True,
        )

        # Numerical checks
        assert isinstance(embeddings, np.ndarray)
        assert embeddings.shape[0] == 3
        assert manifest["embedding_dimensions"] == embeddings.shape[1]
        assert np.isfinite(embeddings).all()

        # Metadata checks
        assert len(meta_df) == 3
        assert list(meta_df["comment_id"]) == ["c1", "c2", "c3"]
        assert list(meta_df["conversation_id"]) == ["thread_1", "thread_1", "thread_1"]

        # Resumability check: reloading without force_recompute should return existing files
        embs_cached, meta_cached, manifest_cached = generator.generate_embeddings(
            records=cleaned_records,
            output_dir=tmp_dir,
            force_recompute=False,
        )
        assert embs_cached.shape == embeddings.shape
        assert len(meta_cached) == 3
